var indexSectionsWithContent =
{
  0: "acdglmrstwy",
  1: "acglmrstwy",
  2: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Файлы",
  2: "Функции"
};

